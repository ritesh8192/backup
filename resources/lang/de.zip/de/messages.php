<?php

return [
 'welcome' => 'Welcome to our applicationb fsdfsdf'
];
